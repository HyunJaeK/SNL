﻿using UnityEngine;
using System.Collections;

public class ArmoEffect : MonoBehaviour {

	public float ArmoSpeed;
	// Use this for initialization
	void Start () {
		ArmoSpeed = 50f;
		Destroy (gameObject, 0.5f);
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (new Vector3(0.8f,-0.01f,0.1f) * Random.Range(50f,100f)* Time.deltaTime);
	}
}
